
def florida_getEnhancedLocation(location):
	return add_state(location, "Florida")