__author__ = 'dipsy'


providers = {
"1":	"Backpage",
"2":	"Craigslist",
"3":	"Classivox",
"4":	"MyProviderGuide",
"5":	"NaughtyReviews",
"6":	"Redbook",
"7":	"Cityvibe",
"8":	"Massagetroll",
"9":	"Redbook Forum",
"10":   "Cityxguide",
"11":   "Cityxguide Forum",
"12":   "Rubads",
"13":   "Anunico",
"14":   "SipSap",
"15":   "Escorts In College",
"16":   "Escortphonelist",
"17":   "EroticMugshots",
"18":   "EscortAds.XXX",
"19":   "Escorts Inca",
"20":   "escortsinthe.us",
"21":   "Live Escort Reviews",
"22":   "MyProviderGuide Forum",
"23":   "USA Sex Guide",
"24":   "The Erotic Review",
"25":   "AdultSearch",
"26":   "Happy Massage",
"27":   "UtopiaGuide",
"28":   "Missing Kids",
"29":   "Alibaba",
"30":   "Just Landed",
"31":   "Gmdu",
"32":   "Tradekey",
"33":   "Manpowervacancy",
"34":   "Gulf Jobs Bank",
"35":   "EC21"
}

def getProviderName(id, url):
    return providers[id]
